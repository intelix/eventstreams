/*
 * Copyright 2014 Intelix Pty Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package hq.flows.core

import java.net.InetSocketAddress

import akka.actor.{ActorRef, ActorRefFactory, Props}
import akka.io.Udp.Unbind
import akka.io.{IO, Udp}
import akka.stream.actor.ActorPublisherMessage.Request
import akka.util.ByteString
import common.ToolExt.configHelper
import common.actors._
import common.{NowProvider, Fail, JsonFrame}
import hq.flows.core.Builder.TapActorPropsType
import org.joda.time.DateTime
import play.api.libs.json.{JsNumber, JsString, JsValue, Json}

import scala.annotation.tailrec
import scala.collection.mutable
import scala.util.Try
import scalaz.Scalaz._
import scalaz._

private[core] object StatsdInputBuilder extends BuilderFromConfig[TapActorPropsType] {
  val configId = "statsd"

  override def build(props: JsValue, maybeData: Option[Condition]): \/[Fail, TapActorPropsType] =
    for (
      id <- props ~> 'id \/> Fail(s"Invalid statsd input configuration. Missing 'id' value. Contents: ${Json.stringify(props)}")
    ) yield StatsdActor.props(id, props)
}

private object StatsdActor {
  def props(id: String, config: JsValue) = Props(new StatsdActor(id, config))

  def start(id: String, config: JsValue)(implicit f: ActorRefFactory) = f.actorOf(props(id, config))
}

private class StatsdActor(id: String, config: JsValue)
  extends ShutdownablePublisherActor[JsonFrame]
  with ActorWithComposableBehavior
  with PipelineWithStatesActor
  with ActorWithTicks
  with NowProvider {

  implicit val system = context.system

  val StatsdParser = "([^:]+):([^|]+)\\|(\\w+)".r

  val host = config ~> 'host | "localhost"
  val port = config +> 'port | 12345
  val parsePayload = config ?> 'parsePayload | true
  val queue = mutable.Queue[String]()
  var openSocket: Option[ActorRef] = None

  override def commonBehavior: Receive = handler orElse super.commonBehavior

  override def preStart(): Unit = {
    super.preStart()
    logger.info(s"About to start Statsd listener $id")
  }


  override def postStop(): Unit = {
    closePort()
    super.postStop()
  }

  override def becomeActive(): Unit = {
    openPort()
    logger.info(s"Becoming active - new accepting messages from statsd [$id]")
    super.becomeActive()
  }

  override def becomePassive(): Unit = {
    closePort()
    logger.info(s"Becoming passive - no longer accepting messages from gate [$id] - all messages will be dropped")
    super.becomePassive()
  }

  def handler: Receive = {
    case Udp.Received(data, remote) => enqueue(data)
    case Udp.Bound(local) => openSocket = Some(sender())
    case Udp.Unbound =>
      logger.debug(s"Unbound!")
      context.stop(self)
      openSocket = None
    case Request(n) => logger.debug(s"Downstream requested $n messages")
  }

  override def processTick(): Unit = {
    deliverIfPossible()
    super.processTick()
  }

  private def openPort() =
    IO(Udp) ! Udp.Bind(self, new InetSocketAddress(host, port))

  private def closePort() = {
    openSocket.foreach { actor =>
      logger.debug(s"Unbind -> $actor")
      actor ! Unbind
    }
  }

  private def parseStatsdMessage(data: String): JsValue = data match {
    case StatsdParser(b, v, t) =>

      val value = t match {
        case "s" => \/-(JsString(v))
        case _ => Try(\/-(JsNumber(BigDecimal(v)))).recover {
          case _ =>
            logger.warn(s"Unparsable number in the statsd payload $data")
            -\/(s"Unparsable number in the statsd payload $data")
        }.get
      }
      value match {
        case -\/(x) => Json.obj(
          "valid" -> false,
          "error" -> x
        )
        case \/-(value) => Json.obj(
          "valid" -> true,
          "bucket" -> b,
          "value" -> value,
          "type" -> t
        )

      }
    case s =>
      logger.warn(s"Invalid statsd payload: $data")
      Json.obj(
        "valid" -> false
      )
  }

  private def parse(data: String) = {

    Some(JsonFrame(Json.obj(
      "tags" -> Json.arr("source"),
      "id" -> id,
      DateInstruction.default_targetFmtField -> DateTime.now().toString(DateInstruction.default),
      DateInstruction.default_targetTsField -> DateTime.now().getMillis,
      "value" -> data,
      "statsd" -> (if (!parsePayload) Json.obj() else parseStatsdMessage(data)),
      "source" -> Json.obj()),
      ctx = Map[String, JsValue]("source.gate" -> JsString(id))))
  }

  @tailrec
  private def deliverIfPossible(): Unit = {
    if (isActive && isPipelineActive && totalDemand > 0 && queue.size > 0) {
      parse(queue.dequeue()) foreach onNext
      deliverIfPossible()
    }
  }

  private def enqueue(data: ByteString) = {
    if (isPipelineActive) {
      logger.info(s"Statsd input $id received: $data")
      val elements = data.utf8String.split('\n')
      elements foreach (queue.enqueue(_))

      // TODO at the moment we are using unbounded queue and UDP are not back-pressured, so it is possible to hit OOM
      // to fix this we need a combination of aggregation/dropping in place

      deliverIfPossible()
    } else {
      logger.info(s"Statsd input $id is not active, message dropped: $data")
    }
  }

}

